const scantool_Funcs = ['DSMRdy','Signals_Std','DTR','DIUMPR','I15031_srv9','DFES_xAsgnFrzFrSig',];

