class Common {

}

Common.PRELOADING_WINDOW_SIZE = {
    width: 650,
    height: 600
};

module.exports = Common;